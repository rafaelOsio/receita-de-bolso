package br.com.receita_de_bolso.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.com.receita_de_bolso.R;

public class ReceitasFragment extends Fragment {


    public ReceitasFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_receitas, container, false);
    }

    public static ReceitasFragment newInstance() {
        return new ReceitasFragment();
    }

}
